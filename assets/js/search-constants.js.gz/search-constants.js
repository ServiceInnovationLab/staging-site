var JEKYLL_PAGES_API_SEARCH_INDEX_URL = '/staging-site/search-index.json';
